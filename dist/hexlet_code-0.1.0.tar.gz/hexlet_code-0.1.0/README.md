### Hexlet tests and linter status:
[![Actions Status](https://github.com/itunasalmon/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/itunasalmon/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/098a93a1c04b1b826c44/maintainability)](https://codeclimate.com/github/itunasalmon/python-project-49/maintainability)
[![asciicast](https://asciinema.org/a/gP2waCQyB9uEOoe7wrg7VKoqs.svg)](https://asciinema.org/a/gP2waCQyB9uEOoe7wrg7VKoqs)
[![asciicast](https://asciinema.org/a/660605.svg)](https://asciinema.org/a/660605)